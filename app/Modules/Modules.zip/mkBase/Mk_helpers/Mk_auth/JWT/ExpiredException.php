<?php
namespace App\Modules\mkBase\Mk_helpers\Mk_auth\JWT;

class ExpiredException extends \UnexpectedValueException
{

}
