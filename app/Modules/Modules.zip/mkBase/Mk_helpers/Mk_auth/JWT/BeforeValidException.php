<?php
namespace App\Modules\mkBase\Mk_helpers\Mk_auth\JWT;

class BeforeValidException extends \UnexpectedValueException
{

}
